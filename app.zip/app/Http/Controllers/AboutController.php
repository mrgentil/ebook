<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function index()
    {
        $about_categories = Category::query()->with('books')->where('order', 3)
            ->get();
        $counter = 1;
        return view('about.index', compact('about_categories', 'counter'));
    }
}
