<?php

namespace App\Http\Controllers;

use App\Http\Requests\ContactRequest;
use App\Repository\ContactRepository;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index()
    {
        return view('contact.index');
    }

    public function store(ContactRequest $request, ContactRepository $contactRepository)
    {
        $contactRepository->store(
            $request->name, $request->email, $request->phone,
            $request->subject, $request->message
        );

        if($request->ajax()){
            return response()->json('Message envoyé');
        }
        flash('Message envoyé avec succès');
        return redirect()->back();
    }
}
